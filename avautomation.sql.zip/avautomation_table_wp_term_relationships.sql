
-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(110, 1, 0),
(128, 3, 0),
(158, 3, 0),
(182, 3, 0),
(269, 3, 0),
(290, 3, 0),
(298, 3, 0),
(306, 3, 0),
(541, 4, 0),
(580, 3, 0),
(652, 3, 0),
(706, 3, 0),
(748, 3, 0);
