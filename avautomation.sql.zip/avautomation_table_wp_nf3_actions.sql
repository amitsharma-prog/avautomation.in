
-- --------------------------------------------------------

--
-- Table structure for table `wp_nf3_actions`
--

CREATE TABLE `wp_nf3_actions` (
  `id` int(11) NOT NULL,
  `title` longtext,
  `key` longtext,
  `type` longtext,
  `active` tinyint(1) DEFAULT '1',
  `parent_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `label` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wp_nf3_actions`
--

INSERT INTO `wp_nf3_actions` (`id`, `title`, `key`, `type`, `active`, `parent_id`, `created_at`, `updated_at`, `label`) VALUES
(1, '', '', 'save', 1, 1, '2019-09-04 05:56:50', '2019-09-04 05:56:50', 'Store Submission'),
(2, '', '', 'email', 1, 1, '2019-09-04 05:56:53', '2019-09-04 05:56:52', 'Email Confirmation'),
(3, '', '', 'email', 1, 1, '2019-09-04 05:56:56', '2019-09-04 05:56:55', 'Email Notification'),
(4, '', '', 'successmessage', 1, 1, '2019-09-04 05:56:58', '2019-09-04 05:56:57', 'Success Message');
