
-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'avautomation'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice,plugin_editor_notice,text_widget_custom_html'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:10:{s:64:\"86191fe69b1db50897039670cf238c38288e05fd0a162fe6927f05ec969f99d0\";a:4:{s:10:\"expiration\";i:1568781043;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1567571443;}s:64:\"b2407613fc86ba68dae3c288d0d088a4053ed27782235733142702af50795d07\";a:4:{s:10:\"expiration\";i:1568782470;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568609670;}s:64:\"cfbac1adc53b7582763ae81b9ba59f4a9b2b4557d8c8ca3a2960543d283377cc\";a:4:{s:10:\"expiration\";i:1568782475;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568609675;}s:64:\"876222e741c14ed224d1ce1d61fa79c73045405e6e886ed97266cd5e4cb2e44d\";a:4:{s:10:\"expiration\";i:1568784431;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568611631;}s:64:\"8529e88422799a970909a8497da77485569bd27949e7f6c3efefbf01d40635e3\";a:4:{s:10:\"expiration\";i:1568784431;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568611631;}s:64:\"f55384041db5b4efc8053420e9e2703dd2e87226a3d5e95c80a9660966b59a29\";a:4:{s:10:\"expiration\";i:1568799953;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568627153;}s:64:\"5bc47598dbcfb1e2ff4c75e5fba22f3e0c1661d819c408d00c11bcd5cd9dc181\";a:4:{s:10:\"expiration\";i:1568801796;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568628996;}s:64:\"9349b2c59d5130f7a20a311601728cb8fc567c9b8d155e98dc615bea04f29ab9\";a:4:{s:10:\"expiration\";i:1568801796;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568628996;}s:64:\"875d246c8f210f9306dbaeb6660e70f6dce8dcea644c7d1cdf59b0e0fa813ef0\";a:4:{s:10:\"expiration\";i:1568869720;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568696920;}s:64:\"20581682ddd87751642a819ed2d9e41698c4be89254f2e406e2d41c46230ea86\";a:4:{s:10:\"expiration\";i:1568869720;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36\";s:5:\"login\";i:1568696920;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '763'),
(18, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(19, 1, 'wp_user-settings-time', '1568107739'),
(20, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(21, 1, 'metaboxhidden_dashboard', 'a:4:{i:0;s:19:\"dashboard_right_now\";i:1;s:18:\"dashboard_activity\";i:2;s:21:\"dashboard_quick_press\";i:3;s:17:\"dashboard_primary\";}'),
(22, 1, 'edit_soliloquy_per_page', '20'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}'),
(25, 1, 'nav_menu_recently_edited', '3'),
(26, 1, 'enable_custom_fields', ''),
(27, 1, 'closedpostboxes_ngg-manage-gallery', 'a:1:{i:0;s:10:\"gallerydiv\";}'),
(28, 1, 'metaboxhidden_ngg-manage-gallery', 'a:0:{}'),
(29, 1, 'closedpostboxes_page', 'a:0:{}'),
(30, 1, 'metaboxhidden_page', 'a:0:{}'),
(31, 1, 'elementor_introduction', 'a:1:{s:10:\"rightClick\";b:1;}'),
(32, 1, 'closedpostboxes_testimonial', 'a:0:{}'),
(33, 1, 'metaboxhidden_testimonial', 'a:1:{i:0;s:7:\"slugdiv\";}');
