
-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_slider_id`
--

CREATE TABLE `wp_rich_web_slider_id` (
  `id` int(10) UNSIGNED NOT NULL,
  `Slider_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_rich_web_slider_id`
--

INSERT INTO `wp_rich_web_slider_id` (`id`, `Slider_ID`) VALUES
(1, 1),
(2, 2);
