
-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_photo_slider_instal_video`
--

CREATE TABLE `wp_rich_web_photo_slider_instal_video` (
  `id` int(10) UNSIGNED NOT NULL,
  `Sl_Video_Url` varchar(255) NOT NULL,
  `Sl_Number` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_rich_web_photo_slider_instal_video`
--

INSERT INTO `wp_rich_web_photo_slider_instal_video` (`id`, `Sl_Video_Url`, `Sl_Number`) VALUES
(41, '', 1),
(42, '', 1),
(43, '', 1),
(44, '', 1);
