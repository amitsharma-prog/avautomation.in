
-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_photo_slider_instal`
--

CREATE TABLE `wp_rich_web_photo_slider_instal` (
  `id` int(10) UNSIGNED NOT NULL,
  `SL_Img_Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sl_Img_Description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sl_Img_Url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sl_Link_Url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sl_Link_NewTab` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sl_Number` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_rich_web_photo_slider_instal`
--

INSERT INTO `wp_rich_web_photo_slider_instal` (`id`, `SL_Img_Title`, `Sl_Img_Description`, `Sl_Img_Url`, `Sl_Link_Url`, `Sl_Link_NewTab`, `Sl_Number`) VALUES
(41, '', '', 'http://localhost/wordpress/wp-content/uploads/2019/08/5d6a0b2529d17-300x148.png', '', 'undefined', 1),
(42, '', '', 'http://localhost/wordpress/wp-content/uploads/2019/08/safty-sensor-300x137.png', '', 'undefined', 1),
(43, '', '', 'http://localhost/wordpress/wp-content/uploads/2019/08/5d6a040b882b3-300x191.png', '', 'undefined', 1),
(44, '', '', 'http://localhost/wordpress/wp-content/uploads/2019/08/eye-sensor-300x169.png', '', 'undefined', 1);
