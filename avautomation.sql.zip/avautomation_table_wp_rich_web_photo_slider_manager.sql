
-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_photo_slider_manager`
--

CREATE TABLE `wp_rich_web_photo_slider_manager` (
  `id` int(10) UNSIGNED NOT NULL,
  `Slider_Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Slider_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Slider_IMGS_Quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_rich_web_photo_slider_manager`
--

INSERT INTO `wp_rich_web_photo_slider_manager` (`id`, `Slider_Title`, `Slider_Type`, `Slider_IMGS_Quantity`) VALUES
(1, 'AV Automation', 'Thumbnails Slider & Lightbox 1', 4);
